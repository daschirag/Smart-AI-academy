import React from 'react';
import { GraduationCap, UserCog, Users } from 'lucide-react';

interface WelcomeProps {
  onRoleSelect: (role: 'student' | 'teacher' | 'council') => void;
}

const Welcome: React.FC<WelcomeProps> = ({ onRoleSelect }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex flex-col items-center justify-center p-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
          Welcome to Smart AI Academy
        </h1>
        <p className="text-xl text-white opacity-90">
          Personalized Learning Powered by AI
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full">
        <RoleCard
          title="Student"
          description="Access personalized learning paths, AI mentoring, and career guidance"
          icon={<GraduationCap className="w-12 h-12" />}
          onClick={() => onRoleSelect('student')}
        />
        <RoleCard
          title="Teacher"
          description="Manage student progress, grade assignments, and track performance"
          icon={<UserCog className="w-12 h-12" />}
          onClick={() => onRoleSelect('teacher')}
        />
        <RoleCard
          title="Student Council"
          description="Handle grievances and support student community"
          icon={<Users className="w-12 h-12" />}
          onClick={() => onRoleSelect('council')}
        />
      </div>
    </div>
  );
};

interface RoleCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick: () => void;
}

const RoleCard: React.FC<RoleCardProps> = ({ title, description, icon, onClick }) => {
  return (
    <button
      onClick={onClick}
      className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
    >
      <div className="flex flex-col items-center text-center">
        <div className="text-blue-600 mb-4">{icon}</div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{title}</h2>
        <p className="text-gray-600">{description}</p>
      </div>
    </button>
  );
};

export default Welcome;