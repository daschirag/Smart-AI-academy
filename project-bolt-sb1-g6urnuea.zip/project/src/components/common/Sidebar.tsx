import React from 'react';
import { NavLink } from 'react-router-dom';
import * as Icons from 'lucide-react';

interface MenuItem {
  title: string;
  path: string;
  icon: string;
}

interface SidebarProps {
  menuItems: MenuItem[];
  userRole: string;
}

const Sidebar: React.FC<SidebarProps> = ({ menuItems, userRole }) => {
  return (
    <div className="w-64 bg-white h-screen shadow-lg">
      <div className="p-6 border-b">
        <h2 className="text-2xl font-bold text-blue-600 capitalize">{userRole} Portal</h2>
      </div>
      <nav className="p-4">
        {menuItems.map((item) => {
          const Icon = Icons[item.icon as keyof typeof Icons] || Icons.Circle;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center p-3 rounded-lg mb-2 transition-colors ${
                  isActive
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-600 hover:bg-gray-50'
                }`
              }
            >
              <Icon className="w-5 h-5 mr-3" />
              <span>{item.title}</span>
            </NavLink>
          );
        })}
      </nav>
    </div>
  );
};

export default Sidebar;