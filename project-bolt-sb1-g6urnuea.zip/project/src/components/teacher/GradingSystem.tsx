import React, { useState } from 'react';
import { CheckCircle, AlertCircle } from 'lucide-react';

const GradingSystem = () => {
  const [questionType, setQuestionType] = useState<'objective' | 'theory'>('objective');
  const [teacherAnswer, setTeacherAnswer] = useState('');
  const [studentAnswer, setStudentAnswer] = useState('');
  const [result, setResult] = useState<{
    score: number;
    feedback: string;
    report?: string;
  } | null>(null);

  const analyzeAnswer = async () => {
    // In a production environment, this would make an API call to OpenAI
    // For demo purposes, we'll simulate the AI grading
    const simulatedScore = Math.floor(Math.random() * 41) + 60; // Random score between 60-100
    
    const feedback = questionType === 'objective'
      ? `The student's answer is ${simulatedScore}% correct.`
      : `The response demonstrates ${simulatedScore}% understanding of the concept.`;

    const report = `
Grading Report:
---------------
Score: ${simulatedScore}/100

Key Points:
- Main concepts covered
- Accuracy of information
- Clarity of expression

Areas for Improvement:
- Additional examples could strengthen the answer
- More detailed explanations recommended
- Consider citing specific references

Overall Assessment:
The answer shows good understanding but has room for improvement in specific areas.
    `.trim();

    setResult({
      score: simulatedScore,
      feedback,
      report
    });
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">AI Grading System</h1>

      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Question Type
          </label>
          <div className="flex gap-4">
            <button
              onClick={() => setQuestionType('objective')}
              className={`px-4 py-2 rounded-md ${
                questionType === 'objective'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              Objective
            </button>
            <button
              onClick={() => setQuestionType('theory')}
              className={`px-4 py-2 rounded-md ${
                questionType === 'theory'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              Theory
            </button>
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Teacher's Answer (Correct Answer)
          </label>
          <textarea
            value={teacherAnswer}
            onChange={(e) => setTeacherAnswer(e.target.value)}
            className="w-full p-3 border rounded-md h-32"
            placeholder="Enter the correct answer..."
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Student's Answer
          </label>
          <textarea
            value={studentAnswer}
            onChange={(e) => setStudentAnswer(e.target.value)}
            className="w-full p-3 border rounded-md h-32"
            placeholder="Enter the student's answer..."
          />
        </div>

        <button
          onClick={analyzeAnswer}
          disabled={!teacherAnswer || !studentAnswer}
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Grade Answer
        </button>
      </div>

      {result && (
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center gap-2 mb-4">
            {result.score >= 70 ? (
              <CheckCircle className="w-6 h-6 text-green-500" />
            ) : (
              <AlertCircle className="w-6 h-6 text-yellow-500" />
            )}
            <h2 className="text-xl font-semibold">Grading Result</h2>
          </div>

          <div className="mb-4">
            <div className="text-2xl font-bold text-blue-600 mb-2">
              Score: {result.score}%
            </div>
            <p className="text-gray-600">{result.feedback}</p>
          </div>

          {result.report && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-2">Detailed Report</h3>
              <pre className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap font-mono text-sm">
                {result.report}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default GradingSystem;