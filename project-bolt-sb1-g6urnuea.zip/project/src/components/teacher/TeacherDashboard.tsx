import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Sidebar from '../common/Sidebar';
import StudentGrades from './StudentGrades';
import GradingSystem from './GradingSystem';
import StudentAnalytics from './StudentAnalytics';

const TeacherDashboard = () => {
  const menuItems = [
    { title: 'Student Grades', path: 'grades', icon: 'GraduationCap' },
    { title: 'AI Grading', path: 'grading', icon: 'Bot' },
    { title: 'Student Analytics', path: 'analytics', icon: 'BarChart' },
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar menuItems={menuItems} userRole="teacher" />
      <div className="flex-1 overflow-auto">
        <Routes>
          <Route path="/grades" element={<StudentGrades />} />
          <Route path="/grading" element={<GradingSystem />} />
          <Route path="/analytics" element={<StudentAnalytics />} />
        </Routes>
      </div>
    </div>
  );
};

export default TeacherDashboard;