import React from 'react';
import { BarChart as BarChartIcon, PieChart as PieChartIcon, TrendingUp } from 'lucide-react';

const StudentAnalytics = () => {
  const domainDistribution = {
    'Web Development': 35,
    'Mobile Development': 25,
    'Data Science': 20,
    'Machine Learning': 15,
    'Cloud Computing': 5
  };

  const averageScores = {
    'Web Development': 85,
    'Mobile Development': 82,
    'Data Science': 78,
    'Machine Learning': 80,
    'Cloud Computing': 75
  };

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Student Analytics</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center gap-2 mb-4">
            <PieChartIcon className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold">Domain Distribution</h2>
          </div>
          <div className="space-y-4">
            {Object.entries(domainDistribution).map(([domain, percentage]) => (
              <div key={domain}>
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>{domain}</span>
                  <span>{percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center gap-2 mb-4">
            <BarChartIcon className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold">Average Scores by Domain</h2>
          </div>
          <div className="space-y-4">
            {Object.entries(averageScores).map(([domain, score]) => (
              <div key={domain}>
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>{domain}</span>
                  <span>{score}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-green-500 h-2 rounded-full"
                    style={{ width: `${score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md md:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold">Performance Trends</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: 'Average Score', value: '82%', trend: '+5%' },
              { label: 'Active Students', value: '245', trend: '+12%' },
              { label: 'Completion Rate', value: '78%', trend: '+3%' }
            ].map((stat, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <div className="text-gray-600 mb-1">{stat.label}</div>
                <div className="text-2xl font-bold text-gray Continuing the StudentAnalytics.tsx file content from where it was cut off:

<boltArtifact id="complete-student-analytics" title="Complete Student Analytics Component">
<boltAction type="file" filePath="src/components/teacher/StudentAnalytics.tsx">import React from 'react';
import { BarChart as BarChartIcon, PieChart as PieChartIcon, TrendingUp } from 'lucide-react';

const StudentAnalytics = () => {
  const domainDistribution = {
    'Web Development': 35,
    'Mobile Development': 25,
    'Data Science': 20,
    'Machine Learning': 15,
    'Cloud Computing': 5
  };

  const averageScores = {
    'Web Development': 85,
    'Mobile Development': 82,
    'Data Science': 78,
    'Machine Learning': 80,
    'Cloud Computing': 75
  };

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Student Analytics</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center gap-2 mb-4">
            <PieChartIcon className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold">Domain Distribution</h2>
          </div>
          <div className="space-y-4">
            {Object.entries(domainDistribution).map(([domain, percentage]) => (
              <div key={domain}>
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>{domain}</span>
                  <span>{percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center gap-2 mb-4">
            <BarChartIcon className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold">Average Scores by Domain</h2>
          </div>
          <div className="space-y-4">
            {Object.entries(averageScores).map(([domain, score]) => (
              <div key={domain}>
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>{domain}</span>
                  <span>{score}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-green-500 h-2 rounded-full"
                    style={{ width: `${score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md md:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold">Performance Trends</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: 'Average Score', value: '82%', trend: '+5%' },
              { label: 'Active Students', value: '245', trend: '+12%' },
              { label: 'Completion Rate', value: '78%', trend: '+3%' }
            ].map((stat, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <div className="text-gray-600 mb-1">{stat.label}</div>
                <div className="flex items-end gap-2">
                  <span className="text-2xl font-bold text-gray-800">{stat.value}</span>
                  <span className="text-sm text-green-500">{stat.trend}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentAnalytics;