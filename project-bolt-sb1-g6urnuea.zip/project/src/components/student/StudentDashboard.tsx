import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Sidebar from '../common/Sidebar';
import PersonalizedLearning from './PersonalizedLearning';
import Grievance from './Grievance';
import AIMentor from './AIMentor';
import CareerLinks from './CareerLinks';

const StudentDashboard = () => {
  const menuItems = [
    { title: 'Personalized Learning', path: 'learning', icon: 'BookOpen' },
    { title: 'Grievance System', path: 'grievance', icon: 'MessageSquare' },
    { title: 'AI Mentor', path: 'mentor', icon: 'Bot' },
    { title: 'Career Links', path: 'career', icon: 'Link' },
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar menuItems={menuItems} userRole="student" />
      <div className="flex-1 overflow-auto">
        <Routes>
          <Route path="/learning" element={<PersonalizedLearning />} />
          <Route path="/grievance" element={<Grievance />} />
          <Route path="/mentor" element={<AIMentor />} />
          <Route path="/career" element={<CareerLinks />} />
        </Routes>
      </div>
    </div>
  );
};

export default StudentDashboard;