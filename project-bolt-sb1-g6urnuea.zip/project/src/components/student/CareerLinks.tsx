import React, { useState } from 'react';
import { ExternalLink, Youtube } from 'lucide-react';

interface DomainLinks {
  [key: string]: {
    title: string;
    url: string;
    description: string;
  }[];
}

const CareerLinks = () => {
  const [selectedDomain, setSelectedDomain] = useState('');

  const domains = [
    'Web Development',
    'Mobile Development',
    'Data Science',
    'Machine Learning',
    'Cloud Computing',
    'Cybersecurity'
  ];

  const domainLinks: DomainLinks = {
    'Web Development': [
      {
        title: 'Complete Web Development Bootcamp',
        url: 'https://www.youtube.com/watch?v=QA0XpGhiz5w',
        description: 'Learn modern web development from scratch'
      },
      {
        title: 'React.js Full Course',
        url: 'https://www.youtube.com/watch?v=bMknfKXIFA8',
        description: 'Master React.js with practical projects'
      },
      {
        title: 'Full Stack Development Tutorial',
        url: 'https://www.youtube.com/watch?v=nu_pCVPKzTk',
        description: 'Build full-stack applications with modern technologies'
      }
    ],
    'Mobile Development': [
      {
        title: 'React Native Tutorial for Beginners',
        url: 'https://www.youtube.com/watch?v=0-S5a0eXPoc',
        description: 'Build mobile apps with React Native'
      },
      {
        title: 'Flutter Complete Course',
        url: 'https://www.youtube.com/watch?v=VPvVD8t02U8',
        description: 'Create beautiful mobile applications with Flutter'
      }
    ],
    // Add more domains with their respective links
  };

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Career Learning Resources</h1>
      
      <div className="max-w-4xl">
        <div className="mb-8">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Your Domain
          </label>
          <select
            value={selectedDomain}
            onChange={(e) => setSelectedDomain(e.target.value)}
            className="w-full p-2 border rounded-md"
          >
            <option value="">Select a domain...</option>
            {domains.map((domain) => (
              <option key={domain} value={domain}>
                {domain}
              </option>
            ))}
          </select>
        </div>

        {selectedDomain && domainLinks[selectedDomain] ? (
          <div className="grid gap-6">
            {domainLinks[selectedDomain].map((link, index) => (
              <a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-semibold text-blue-600 mb-2 flex items-center gap-2">
                      <Youtube className="w-6 h-6 text-red-600" />
                      {link.title}
                    </h3>
                    <p className="text-gray-600">{link.description}</p>
                  </div>
                  <ExternalLink className="w-5 h-5 text-gray-400" />
                </div>
              </a>
            ))}
          </div>
        ) : selectedDomain ? (
          <div className="text-center p-8 bg-gray-50 rounded-lg">
            <p className="text-gray-600">Resources for this domain will be added soon.</p>
          </div>
        ) : null}
      </div>
    </div>
  );
};

export default CareerLinks;