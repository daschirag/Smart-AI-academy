import React, { useState } from 'react';

const domains = [
  'Web Development',
  'Mobile Development',
  'Data Science',
  'Machine Learning',
  'Cloud Computing',
  'Cybersecurity',
];

const PersonalizedLearning = () => {
  const [selectedDomain, setSelectedDomain] = useState('');
  const [quizScore, setQuizScore] = useState<number | ''>('');
  const [learningPath, setLearningPath] = useState<string[]>([]);

  const generateLearningPath = () => {
    // This is a simplified example. In a real application, this would be more sophisticated
    if (quizScore === '') return;
    
    const score = Number(quizScore);
    let topics: string[] = [];
    
    if (selectedDomain === 'Web Development') {
      if (score < 40) {
        topics = ['HTML Basics', 'CSS Fundamentals', 'JavaScript Introduction'];
      } else if (score < 70) {
        topics = ['React Basics', 'State Management', 'API Integration'];
      } else {
        topics = ['Advanced React Patterns', 'Performance Optimization', 'Testing'];
      }
    }
    // Add similar logic for other domains
    
    setLearningPath(topics);
  };

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Personalized Learning Path</h1>
      
      <div className="max-w-2xl space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Your Domain
          </label>
          <select
            value={selectedDomain}
            onChange={(e) => setSelectedDomain(e.target.value)}
            className="w-full p-2 border rounded-md"
          >
            <option value="">Select a domain...</option>
            {domains.map((domain) => (
              <option key={domain} value={domain}>
                {domain}
              </option>
            ))}
          </select>
        </div>

        {selectedDomain && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Enter Your Quiz Score (0-100)
            </label>
            <input
              type="number"
              min="0"
              max="100"
              value={quizScore}
              onChange={(e) => setQuizScore(Number(e.target.value))}
              className="w-full p-2 border rounded-md"
            />
          </div>
        )}

        {selectedDomain && quizScore !== '' && (
          <button
            onClick={generateLearningPath}
            className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700"
          >
            Generate Learning Path
          </button>
        )}

        {learningPath.length > 0 && (
          <div className="mt-8">
            <h2 className="text-xl font-semibold mb-4">Recommended Learning Path:</h2>
            <ol className="list-decimal pl-6 space-y-2">
              {learningPath.map((topic, index) => (
                <li key={index} className="text-lg">
                  {topic}
                </li>
              ))}
            </ol>
          </div>
        )}
      </div>
    </div>
  );
};

export default PersonalizedLearning;