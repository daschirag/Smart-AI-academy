import React, { useState } from 'react';
import { AlertTriangle, CheckCircle, Send } from 'lucide-react';

interface GrievanceType {
  id: string;
  title: string;
  description: string;
  priority: 'high' | 'low';
  status: 'pending' | 'resolved';
  ticketNumber: string;
}

const Grievance = () => {
  const [grievances, setGrievances] = useState<GrievanceType[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const determinePriority = (text: string): 'high' | 'low' => {
    const urgentKeywords = ['urgent', 'immediate', 'emergency', 'critical', 'serious'];
    const lowercaseText = text.toLowerCase();
    return urgentKeywords.some(keyword => lowercaseText.includes(keyword)) ? 'high' : 'low';
  };

  const generateTicketNumber = () => {
    return `TICKET-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newGrievance: GrievanceType = {
      id: Date.now().toString(),
      title,
      description,
      priority: determinePriority(description),
      status: 'pending',
      ticketNumber: generateTicketNumber()
    };

    setGrievances([newGrievance, ...grievances]);
    setTitle('');
    setDescription('');
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Grievance System</h1>
      
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md mb-8">
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2 border rounded-md"
            required
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-2 border rounded-md h-32"
            required
          />
        </div>
        
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 flex items-center justify-center gap-2"
        >
          <Send className="w-4 h-4" />
          Submit Grievance
        </button>
      </form>

      <div className="space-y-4">
        {grievances.map((grievance) => (
          <div
            key={grievance.id}
            className="bg-white p-6 rounded-lg shadow-md"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold">{grievance.title}</h3>
                <p className="text-sm text-gray-500">Ticket: {grievance.ticketNumber}</p>
              </div>
              <div className="flex items-center">
                {grievance.priority === 'high' ? (
                  <span className="flex items-center text-red-600">
                    <AlertTriangle className="w-4 h-4 mr-1" />
                    High Priority
                  </span>
                ) : (
                  <span className="flex items-center text-yellow-600">
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Low Priority
                  </span>
                )}
              </div>
            </div>
            <p className="text-gray-700 mb-4">{grievance.description}</p>
            <div className="flex justify-between items-center text-sm">
              <span className={`px-3 py-1 rounded-full ${
                grievance.status === 'pending'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-green-100 text-green-800'
              }`}>
                {grievance.status.charAt(0).toUpperCase() + grievance.status.slice(1)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Grievance;