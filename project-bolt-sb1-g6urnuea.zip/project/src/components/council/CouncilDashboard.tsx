import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Sidebar from '../common/Sidebar';
import GrievanceManagement from './GrievanceManagement';

const CouncilDashboard = () => {
  const menuItems = [
    { title: 'Grievance Management', path: 'grievances', icon: 'MessageSquare' },
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar menuItems={menuItems} userRole="council" />
      <div className="flex-1 overflow-auto">
        <Routes>
          <Route path="/grievances" element={<GrievanceManagement />} />
        </Routes>
      </div>
    </div>
  );
};

export default CouncilDashboard;