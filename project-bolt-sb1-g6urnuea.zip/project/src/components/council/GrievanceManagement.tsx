import React, { useState } from 'react';
import { AlertTriangle, CheckCircle, MessageSquare } from 'lucide-react';

interface Grievance {
  id: string;
  ticketNumber: string;
  title: string;
  description: string;
  priority: 'high' | 'low';
  status: 'pending' | 'resolved';
  response?: string;
}

const GrievanceManagement = () => {
  const [grievances] = useState<Grievance[]>([
    {
      id: '1',
      ticketNumber: 'TICKET-ABC123',
      title: 'Course Material Access Issue',
      description: 'Unable to access the web development course materials. This is urgent as I have an assignment due tomorrow.',
      priority: 'high',
      status: 'pending'
    },
    {
      id: '2',
      ticketNumber: 'TICKET-DEF456',
      title: 'Feedback Request',
      description: 'Would like to get more detailed feedback on my recent project submission.',
      priority: 'low',
      status: 'pending'
    }
  ]);

  const [selectedGrievance, setSelectedGrievance] = useState<Grievance | null>(null);
  const [response, setResponse] = useState('');

  const handleSubmitResponse = () => {
    if (!selectedGrievance || !response) return;
    
    // In a real application, this would update the database
    console.log('Submitting response:', {
      grievanceId: selectedGrievance.id,
      response
    });
    
    setResponse('');
    setSelectedGrievance(null);
  };

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Grievance Management</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">Pending Grievances</h2>
          <div className="space-y-4">
            {grievances.map((grievance) => (
              <div
                key={grievance.id}
                className={`bg-white p-6 rounded-lg shadow-md cursor-pointer transition-all ${
                  selectedGrievance?.id === grievance.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedGrievance(grievance)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{grievance.title}</h3>
                    <p className="text-sm text-gray-500">Ticket: {grievance.ticketNumber}</p>
                  </div>
                  <div className="flex items-center">
                    {grievance.priority === 'high' ? (
                      <span className="flex items-center text-red-600">
                        <AlertTriangle className="w-4 h-4 mr-1" />
                        High Priority
                      </span>
                    ) : (
                      <span className="flex items-center text-yellow-600">
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Low Priority
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-gray-700 mb-4">{grievance.description}</p>
                <div className="flex justify-between items-center text-sm">
                  <span className={`px-3 py-1 rounded-full ${
                    grievance.status === 'pending'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {grievance.status.charAt(0).toUpperCase() + grievance.status.slice(1)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          {selectedGrievance ? (
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Respond to Grievance</h2>
              <div className="mb-4">
                <h3 className="font-medium text-gray-700">Selected Ticket</h3>
                <p className="text-sm text-gray-500">{selectedGrievance.ticketNumber}</p>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Response
                </label>
                <textarea
                  value={response}
                  onChange={(e) => setResponse(e.target.value)}
                  className="w-full p-3 border rounded-md h-32"
                  placeholder="Type your response..."
                />
              </div>
              <div className="flex gap-4">
                <button
                  onClick={handleSubmitResponse}
                  disabled={!response}
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  Send Response
                </button>
                <button
                  onClick={() => setSelectedGrievance(null)}
                  className="px-4 py-2 border rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 p-8 rounded-lg text-center">
              <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Select a grievance to respond</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GrievanceManagement;