import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Welcome from './components/Welcome';
import StudentDashboard from './components/student/StudentDashboard';
import TeacherDashboard from './components/teacher/TeacherDashboard';
import CouncilDashboard from './components/council/CouncilDashboard';

function App() {
  const [userRole, setUserRole] = useState<'student' | 'teacher' | 'council' | null>(null);

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          <Route 
            path="/" 
            element={
              !userRole ? (
                <Welcome onRoleSelect={setUserRole} />
              ) : (
                <Navigate 
                  to={`/${userRole}`} 
                  replace 
                />
              )
            } 
          />
          <Route path="/student/*" element={<StudentDashboard />} />
          <Route path="/teacher/*" element={<TeacherDashboard />} />
          <Route path="/council/*" element={<CouncilDashboard />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;